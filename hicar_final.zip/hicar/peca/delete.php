<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';

    $idPeca = null;
    if(!empty($_GET['id'])) {
        $idPeca = $_REQUEST['id'];
    }
    
    if(null==$idPeca) {
        header("Location: index.php");
    } else {
       $pdo = Banco::conectar();
       $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = "SELECT * FROM peca where idPeca = ?";
       $q = $pdo->prepare($sql);
       $q->execute(array($idPeca));
       $data = $q->fetch(PDO::FETCH_ASSOC);
       Banco::desconectar();
    }

    if(!empty($_POST)) {
        $idPeca = $_POST['idPeca'];
        //Delete do banco:
        $pdo = Banco::conectar();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM peca where idPeca = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($idPeca));
        Banco::desconectar();
        header("Location: index.php");
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
    <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top:100px">
        <div class="container">
            <div class="span10 offset1">
                <div class="row">
                    <h3 class="well">Excluir Peça</h3>
                </div>
                <form class="form-horizontal" action="delete.php?id=<?php echo $idPeca?>" method="POST">
                    <input type="hidden" name="idPeca" value="<?php echo $idPeca;?>"/>
                    <div class="alert alert-danger"> Deseja excluir a peça?
                    </div>
                    <div class="form actions">
                        <button type="submit" class="btn btn-danger">Sim</button>
                        <a href="index.php" type="btn" class="btn btn-default">Não</a>
                    </div>
                </form>
            </div>           
        </div>
    </body>    
</html>

