<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';

    $idServico = null;
    if(!empty($_GET['id'])) {
        $idServico = $_REQUEST['id'];
    }
    
    if(null==$idServico) {
        header("Location: index.php");
    } else {
       $pdo = Banco::conectar();
       $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = "SELECT * FROM servico where idServico = ?";
       $q = $pdo->prepare($sql);
       $q->execute(array($idServico));
       $data = $q->fetch(PDO::FETCH_ASSOC);
       Banco::desconectar();
    }

    if(!empty($_POST)) {
        $idServico = $_POST['idServico'];
        //Delete do banco:
        $pdo = Banco::conectar();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM servico where idServico = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($idServico));
        Banco::desconectar();
        header("Location: index.php");
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
    <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top:100px">
        <div class="container">
            <div class="span10 offset1">
                <div class="row">
                    <h3 class="well">Excluir Serviço</h3>
                </div>
                <form class="form-horizontal" action="delete.php?id=<?php echo $idServico?>" method="POST">
                    <input type="hidden" name="idServico" value="<?php echo $idServico;?>"/>
                    <div class="alert alert-danger"> Deseja excluir o serviço?
                    </div>
                    <div class="form actions">
                        <button type="submit" class="btn btn-danger">Sim</button>
                        <a href="index.php" type="btn" class="btn btn-default">Não</a>
                    </div>
                </form>
            </div>           
        </div>
    </body>    
</html>

