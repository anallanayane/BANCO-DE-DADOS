<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';

    $idServico = null;
    if(!empty($_GET['id'])) {
        $idServico = $_REQUEST['id'];
    }
    
    if(null==$idServico) {
        header("Location: index.php");
    } else {
       $pdo = Banco::conectar();
       $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = "SELECT * FROM servico where idServico = ?";
       $q = $pdo->prepare($sql);
       $q->execute(array($idServico));
       $data = $q->fetch(PDO::FETCH_ASSOC);
       Banco::desconectar();
    }

	if(!empty($_POST)) {
		
		//Acompanha os erros de validação
        $nomeErro  = null;
        $tempoErro = null;
		$valorErro = null;
		
        $nome  = $_POST['nome'];
        $tempo = $_POST['tempo'];
		$valor = $_POST['valor'];
        
        //Validaçao dos campos:
		$validacao = true;
		if(empty($nome)) {
		    $nomeErro = 'Por favor digite o nome!';
		    $validacao = false;
        }
        
        if(empty($tempo)) {
		    $tempoErro = 'Por favor digite o tempo médio!';
		    $validacao = false;
		}

		if(empty($valor)) {
		    $valorErro = 'Por favor digite o valor!';
		    $validacao = false;
		}

		// update data
		if ($validacao) {
            $pdo = Banco::conectar();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE servico  set nome = ?, tempoMedio = ?, valor = ? WHERE idServico = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($nome, $tempo, $valor, $idServico));
            Banco::desconectar();
            header("Location: index.php");
		}
	} else {
        $pdo = Banco::conectar();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM servico where idServico = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($idServico));
		$data  = $q->fetch(PDO::FETCH_ASSOC);
        $nome  = $data['nome'];
        $tempo = $data['tempoMedio'];
		$valor = $data['valor'];
        Banco::desconectar();
	}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
<?php include '../cabecalho_cadastros.php'; ?>
    <meta charset="utf-8">
    <link   href="../css/bootstrap.min.css" rel="stylesheet">
    <script src="../js/bootstrap.min.js"></script>
</head>
 
<body style="padding-top:100px">
    <div class="container">
        <div class="span10 offset1">
            <div class="row">
                <h3 class="well"> Atualizar Serviço </h3>
            </div>
            <form class="form-horizontal" action="update.php?id=<?php echo $idServico?>" method="post">
                <div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
                    <label class="control-label">Nome</label>
                    <div class="controls">
                        <input size= "50" name="nome" type="text" placeholder="Nome" required value="<?php echo !empty($nome)?$nome: '';?>">
                        <?php if(!empty($nomeErro)): ?>
                            <span class="help-inline"><?php echo $nomeErro;?></span>
                        <?php endif;?>
                    </div>
                </div>
                <div class="control-group <?php echo !empty($tempoErro)?'error ' : '';?>">
                    <label class="control-label">Tempo médio</label>
                    <div class="controls">
                        <input size= "50" name="tempo" type="text" placeholder="Tempo" required value="<?php echo !empty($tempo)?$tempo: '';?>">
                        <?php if(!empty($tempoErro)): ?>
                            <span class="help-inline"><?php echo $tempoErro;?></span>
                        <?php endif;?>
                    </div>
                </div>
                <div class="control-group <?php echo !empty($valorErro)?'error ' : '';?>">
                    <label class="control-label">Valor</label>
                    <div class="controls">
                        <input size= "15" name="valor" type="text" placeholder="valor" required value="<?php echo !empty($valor)?$valor: '';?>">
                        <?php if(!empty($valorErro)): ?>
                            <span class="help-inline"><?php echo $valorErro;?></span>
                        <?php endif;?>
                    </div>
                </div>
                <br/>
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">Atualizar</button>
                    <a href="index.php" type="btn" class="btn btn-default">Voltar</a>
                </div>
            </form>
        </div>
    </div>
  </body>
</html>

