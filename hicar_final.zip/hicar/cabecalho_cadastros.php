    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../_css/estilo.css" type="text/css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <div class="w3-top">
      <div class="w3-bar w3-light-blue" id="myNavbar">
        <a href="../index.php"><img class="w3-image w3-bar-item" 
        src="../_imagens/logo.png" style="width:10%"></a>
        <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>

        <div class="w3-dropdown-hover w3-right w3-light-blue">
              <i class="material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white">person</i> 
              <div class="w3-dropdown-content w3-bar-block w3-border">
                <a href="../pessoa/perfil.php" class="w3-bar-item w3-button w3-hover-blue">Perfil</a>
                <a href="../logout.php" class="w3-bar-item w3-button w3-hover-blue">Sair</a>
              </div> 
        </div>

        <a href="../mensagem.php" class="w3-light-blue material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white w3-right"style="text-decoration: none">email</a>
      <?php
        if($funcionario) {
            echo '<a href="../funcionario/meusservicos.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%;margin-left:5px">Meus Serviços <i class="w3-right material-icons">build</i></a>';
        }
        echo '<a href="../pessoa/meusveiculos.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%;margin-left:5px">Meus Veículos<i class="w3-right material-icons">directions_car</i></a>';
        if($funcionario) {
          echo '<a href="../empresa/index.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%;margin-left:5px">Empresas<i class="w3-right material-icons">store</i></a>';
          echo '<a href="../peca/index.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%;margin-left:5px">Peças<i class="w3-right material-icons">shopping_cart</i></a>';
          echo '<a href="../servico/index.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%;margin-left:5px">Serviços<i class="w3-right material-icons">accessibility</i></a>';
        }
      ?>
      </div>
    </div>