<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Meus Serviços</title>
        <?php include '../cabecalho_cadastros.php'; ?>
    </head>

    <!--Breadcrumbs -->
    <ul class="breadcrumb" style="margin-top:-1%">
        <li><a href="../index.php">Home</a></li>
        <li><a href="../user.php">Funcionário</a></li>
        <li>Meus Serviços</li>
    </ul>
    <!-- Historico de Serviços-->
    <body style="padding-top: 140px">
        <div class="w3-container w3-blue w3-padding " style="margin-left: 415px; margin-right: 415px; height: auto; margin-top:3%">
        <a href="../user.php" class="material-icons w3-text-white w3-padding" style="text-decoration: none; margin-top:1%">arrow_back</a><span class="w3-center w3-xlarge" style="margin-left:5%; margin-bottom:10%">Meus Serviços</span>
        <a href="../user.php" class="material-icons w3-text-white w3-padding w3-right" style=" text-decoration: none; margin-top:1%">close</a></div>
        <div class="w3-container " style="margin-left: 400px; margin-right: 400px; height: 100%;">
            <ul class="w3-ul w3-card-4">
                <li class="w3-bar" onclick="javascript:location.href='../os/index.php'">
                    <span class="w3-large">0rdens de Serviços</span>
                    <i class="material-icons w3-right" id="os0">keyboard_arrow_right</i>
                    <div class="w3-container w3-margin-top" id="div_os0" style="display: none">
                        <hr>
                    </div>
                </li>
                <li class="w3-bar">
                    <span>Iniciar Serviço</span>
                    <i onclick="mudarEstado('service1', 'div_os2')" class="material-icons w3-right" id="service1">keyboard_arrow_right</i>
                    <div class="w3-container w3-margin-top" id="div_os2" style="display: none">
                        
                         <hr>
                    </div>
                </li>
                <li class="w3-bar">
                        <span>Visualizar Serviços Ativos</span>
                        <i onclick="mudarEstado('service2', 'div_os3')" class="material-icons w3-right" id="service2">keyboard_arrow_right</i>
                        <div class="w3-container w3-margin-top" id="div_os3" style="display: none">
                            
                             <hr>
                        </div>
                </li>
                <li class="w3-bar">
                        <span>Cadastrar Serviço</span>
                        <i onclick="mudarEstado('service3', 'div_os4')" class="material-icons w3-right" id="service3">keyboard_arrow_right</i>
                        <div class="w3-container w3-margin-top" id="div_os4" style="display: none">
                            
                             <hr>
                        </div>
                </li>
            </ul>

        </div>
        
        <!-- Footer -->
        <footer class="w3-container w3-center w3-dark-grey w3-margin-top">
        <a href="https://www.facebook.com/" style="text-decoration: none" target="_blank" class="fa fa-facebook-square w3-text-color-white w3-xxlarge w3-padding"></a>
        <a href="https://www.instagram.com/" style="text-decoration: none" target="_blank" class="fa fa-instagram w3-text-color-white w3-margin-top w3-xxlarge"></a>
        <a href="https://www.linkedin.com/" style="text-decoration: none" target="_blank" class="fa fa-linkedin w3-text-color-white w3-xxlarge w3-padding"></a>

        <a href="#"><i class="fa fa-chevron-circle-up w3-right w3-xxlarge" style="margin-top:4%; margin-right:2%;" alt="Início"></i></a>
            <p class="w3-center w3-align">© 2018 Hi-Car All Rights Reserved</p><br/>
        </footer>
    </body>

    <script>
        function mudarEstado(el1, el2){
            var botao = document.getElementById(el2);
            var div = document.getElementById(el2).style.display;
            if(div == "none"){
                document.getElementById(el2).style.display = 'block';
                document.getElementById(el1).innerHTML='keyboard_arrow_down';
            }
            else{
                document.getElementById(el2).style.display = 'none';
                document.getElementById(el1).innerHTML='keyboard_arrow_right';
            }
        }
    </script>
</html>