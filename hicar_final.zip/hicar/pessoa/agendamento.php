<?php
  //error_reporting(E_ALL);
  //ini_set('display_errors', 1);
  session_start();
  if(!isset($_SESSION['usuario'])) {
		header("Location: ../index.php");
  }
  
  require '../banco.php';
  
  $id = $_SESSION['usuario'];

  $empresaErro = null;
  $servicoErro = null;
  $dataErro    = null;
  $horaErro    = null;
  
  $empresa = null;
  $servico = null;
  $dataAg  = null;
  $horaAg  = null;
  $veiculo = null;

  if(!empty($_POST)) {
    $empresa = $_POST['empresa'];
    $servico = $_POST['servico'];
    $dataAg  = $_POST['dataAgenda'];
    $horaAg  = $_POST['horaAgenda'];
    $veiculo = $_POST['veiculo'];
    
    //Validaçao dos campos:
    $validacao = true;
    if(empty($empresa)) {
        $empresaErro = 'Por favor selecione a concessionária!';
        $validacao = false;
    }

    if(empty($servico)) {
        $servicoErro = 'Por favor escolha o serviço!';
        $validacao = false;
    }

    if(empty($dataAg)) {
        $dataErro = 'Data inválida';
        $validacao = false;
    }

    if(empty($horaAg)) {
        $horaErro = 'Hora inválida!';
        $validacao = false;
    }     
            
    //Inserindo no Banco:
    if($validacao) {
      $pdo = Banco::conectar();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO agendamento (idEmpresa, idVeiculo, idServico, data, hora) VALUES(?,?,?,?,?)";
      $q = $pdo->prepare($sql);
      $q->execute(array($empresa, $veiculo, $servico, $dataAg, $horaAg));
      Banco::desconectar();
      header("Location: meusveiculos.php");
    }
  } else {
    if(!isset($_GET['veiculo']))
      header("Location: meusveiculos.php");

    $veiculo = $_GET['veiculo'];
  }
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Agendamento</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../_css/estilo.css" type="text/css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    
  
    <!-- Barra de Menu e Head-->
    <div class="w3-top">
      <div class="w3-bar w3-light-blue" id="myNavbar">
        <a href="../index.php"><img class="w3-image w3-bar-item" 
        src="../_imagens/logo.png" style="width:10%"></a>
        <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>

        <div class="w3-dropdown-hover w3-right w3-light-blue">
              <i class="material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white">person</i> 
              <div class="w3-dropdown-content w3-bar-block w3-border">
                <a href="perfil.php" class="w3-bar-item w3-button w3-hover-blue">Perfil</a>
                <a href="../logout.php" class="w3-bar-item w3-button w3-hover-blue">Sair</a>
              </div> 
        </div>

        <a href="../mensagem.php" class="w3-light-blue material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white w3-right"style="text-decoration: none">email</a>
        
        <a href="meusveiculos.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%">Meus Veículos<i class="w3-right material-icons">
        directions_car</i></a>
      </div>
    </div>
  </head>

   <ul class="breadcrumb" style="margin-top:6%">
        <li><a href="../index.php">Home</a></li>
        <li><a href="../user.php">Usuário</a></li>
        <li><a href="meusveiculos.php">Meus Veículos</a></li>
        <li>Agendamento</li>
    </ul>
  
  <!--Corpo da Pagina - Formulario de Agendamento -->
  <body>
    <div class="Agendamento w3-display-container w3-padding" style="margin-top: -2%" id="agendar">
      <div class="w3-content w3-margin-top w3-padding" style="max-width:50%; opacity: 0.95;">
        <div class="w3-content w3-container w3-center w3-padding-64 w3-align w3-margin-top">
          <form class="w3-container w3-card-4" action="agendamento.php" method="POST">
            <input type="hidden" id="veiculo" name="veiculo" value="<?php echo $veiculo; ?>">
            <h2 class="w3-center">Agendamento de Serviços</h2> <br>
              <div class="w3-section">
                <select class="w3-select" name="empresa">
                  <option value="" disabled selected>Selecione uma Concessionária</option>
                  <?php 
                    $pdo = Banco::conectar();
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $sql = "SELECT * FROM empresa ORDER BY razaoSocial ";
                    $q = $pdo->prepare($sql);
                    $q->execute();
                    while($data = $q->fetch(PDO::FETCH_ASSOC)) {
                      echo '<option value="' . $data['idEmpresa'] . '"';
                      if($empresa == $data['idEmpresa'])
                        echo ' selected';
                      echo '>' . $data['razaoSocial'] . '</option>';
                    }
                    Banco::desconectar();
                  ?>
                </select>
                <?php if(!empty($empresaErro)): ?>
                  <span class="help-inline"><?php echo $empresaErro;?></span>
                <?php endif;?>
              </div>
              <div class="w3-section">
                <select class="w3-select" name="servico">
                  <option value="" disabled selected>Selecione o tipo de serviço</option>
                  <?php 
                    $pdo = Banco::conectar();
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $sql = "SELECT * FROM servico ORDER BY nome";
                    $q = $pdo->prepare($sql);
                    $q->execute();
                    while($data = $q->fetch(PDO::FETCH_ASSOC)) {
                        echo '<option value="' . $data['idServico'] . '"';
                        if($servico == $data['idServico'])
                          echo ' selected';
                        echo '>' . $data['nome'] . ' (' . $data['tempoMedio'] . ' minutos)</option>';
                    }
                    Banco::desconectar();
                  ?>
                </select>
                <?php if(!empty($servicoErro)): ?>
                  <span class="help-inline"><?php echo $servicoErro;?></span>
                <?php endif;?>
              </div>
              <div class="w3-section w3-left">
                  Selecione a Data:
                  <p><input type="date" name="dataAgenda" value="<?php echo !empty($dataAg)?$dataAg: '';?>"></p>
                  <?php if(!empty($dataErro)): ?>
                    <span class="help-inline"><?php echo $dataErro;?></span>
                  <?php endif;?>
              </div>
              <div class="w3-section w3-right">
                  Selecione a Hora:
                  <p><input type="time" name="horaAgenda" min="08:00" max="16:00" value="<?php echo !empty($horaAg)?$horaAg: '';?>"></p>
                  <?php if(!empty($horaErro)): ?>
                    <span class="help-inline"><?php echo $horaErro;?></span>
                  <?php endif;?>
              </div>
              <br/><br/>
              <div class="w3-section w3-half">
                <button class="w3-right w3-button w3-margin-bottom w3-blue w3-hover-light-blue w3-round-large" type="submit">Confirmar Agendamento</button>
                <a href="meusveiculos.php" type="button" class="w3-right w3-button w3-text-red w3-hover-red w3-round-large w3-margin-right">Cancelar</a><br>
              </div>  
          </form>
        </div>
      </div>
    </div>
     <!-- Footer -->
    <footer class="w3-container w3-center w3-dark-grey">
      <a href="https://www.facebook.com/" style="text-decoration: none" target="_blank" class="fa fa-facebook-square w3-text-color-white w3-xxlarge w3-padding"></a>
      <a href="https://www.instagram.com/" style="text-decoration: none" target="_blank" class="fa fa-instagram w3-text-color-white w3-margin-top w3-xxlarge"></a>
      <a href="https://www.linkedin.com/" style="text-decoration: none" target="_blank" class="fa fa-linkedin w3-text-color-white w3-xxlarge w3-padding"></a>

      <a href="#agendar"><i class="fa fa-chevron-circle-up w3-right w3-xxlarge" style="margin-top:4%; margin-right:2%;" alt="Início"></i></a>
        <p class="w3-center w3-align">© 2018 Hi-Car All Rights Reserved</p><br/>
    </footer>
  </body>
</html> 
              
               
            