<?php
	//error_reporting(E_ALL);
	//ini_set('display_errors', 1);
	session_start();
	if(isset($_SESSION['usuario'])) {
		header("Location: ../user.php");
	}
	require '../banco.php';

	$nome     = null;
	$cpf      = null;
	$email    = null;
	$telefone = null;
	$endereco = null;
	$isfunc   = null;
	$empresa  = null;
	$funcao   = null;
	$salario  = null;
	$senha    = null;
	$csenha   = null;
    
	if(!empty($_POST)) {
			//Acompanha os erros de validação
		$nomeErro     = null;
		$cpfErro      = null;
		$emailErro    = null;
		$telefoneErro = null;
		$enderecoErro = null;
		$empresaErro  = null;
		$funcaoErro   = null;
		$salarioErro  = null;
		$senhaErro    = null;
		$csenhaErro   = null;
		
		$nome     = $_POST['nome'];
		$cpf      = $_POST['cpf'];
		$email    = $_POST['email'];
		$telefone = $_POST['telefone'];
		$endereco = $_POST['endereco'];
		$isfunc   = $_POST['isfunc'];
		if($isfunc) {
			$empresa  = $_POST['empresa'];
			$funcao   = $_POST['funcao'];
			$salario  = $_POST['salario'];
		}
		$senha    = $_POST['senha'];
		$csenha   = $_POST['csenha'];
		
		//Validaçao dos campos:
		$validacao = true;
		if(empty($nome)) {
				$nomeErro = 'Por favor digite o seu nome!';
				$validacao = false;
		}

		if(empty($cpf)) {
				$cpfErro = 'Por favor digite o seu CPF!';
				$validacao = false;
		}

		if(empty($email)) {
				$emailErro = 'Por favor digite o endereço de email';
				$validacao = false;
		}
		elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
				$emailErro = 'Por favor digite um endereço de email válido!';
				$validacao = false;
		}

		if(empty($telefone)) {
				$telefoneErro = 'Por favor digite o número do telefone!';
				$validacao = false;
		}

		if(empty($endereco)) {
				$enderecoErro = 'Por favor digite o seu endereço!';
				$validacao = false;
		}        
		
		if($isfunc) {
			if(empty($empresa)) {
				$empresaErro = 'Por favor selecione uma empresa!';
				$validacao = false;
			}

			if(empty($funcao)) {
				$funcaoErro = 'Por favor digite uma função!';
				$validacao = false;
			}

			if(empty($salario)) {
				$salarioErro = 'Por favor digite o valor do salário!';
				$validacao = false;
			}
		}
						
		if(empty($senha)) {
				$senhaErro = 'Por favor informe uma senha!';
				$validacao = false;
		}
		
		if(empty($csenha)) {
				$csenhaErro = 'Por favor informe uma confirmação de senha!';
				$validacao = false;
		}

		if($senha != $csenha)	{
			$senhaErro = 'A senha e a confirmação devem ser iguais!';
			$validacao = false;
		}

		//Inserindo no Banco:
		if($validacao) {
			$pwd_hash = crypt($senha, '$3b$64$');
			$pdo = Banco::conectar();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "INSERT INTO pessoa (nome, cpf, email, telefone, endereco, senha) VALUES(?,?,?,?,?,?)";
			$q = $pdo->prepare($sql);
			$q->execute(array($nome,$cpf,$email,$telefone,$endereco,$pwd_hash));

			$sql = "SELECT idPessoa FROM pessoa WHERE cpf = '" . $cpf . "'";
			$q = $pdo->prepare($sql);
			$q->execute();
			$data = $q->fetch(PDO::FETCH_ASSOC);
			if($data && $isfunc) {
				$sql = "INSERT INTO funcionario (idPessoa, idEmpresa, funcao, salario) VALUES(?,?,?,?)";
				$q = $pdo->prepare($sql);
				$q->execute(array($data['idPessoa'], $empresa, $funcao, $salario));
			} else {
				//ERRO
				//TRATAR
				//echo "<br><br><br><br><br><br>";
				//echo $data . '-' . $isfunc;
				//die();
			}
			Banco::desconectar();
			header("Location: ../index.php");
		}
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Cadastro</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../_css/login-cadastro.css" type="text/css"/>

		<div class="w3-top">
			<div class="w3-bar w3-light-blue" id="myNavbar">
			    <a href="../index.php"><img class="w3-image w3-bar-item" 
			    src="../_imagens/logo.png" style="width:10%"></a>
			    <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>
			</div>
		</div>

		<script>
		function formatar(mascara, documento){
		  var i = documento.value.length;
		  var saida = mascara.substring(0,1);
		  var texto = mascara.substring(i)
		  
		  if (texto.substring(0,1) != saida){
		            documento.value += texto.substring(0,1);
		  }
		  
		}
		function ativarEmpresa() {
			var chk = document.getElementById('isfunc');
			if(chk.checked) {
				document.getElementById('elementosEmpresa').style.display = "block";
			} else {
				document.getElementById('elementosEmpresa').style.display = "none";
			}
		}
	</script>
	</head>
	<body>
		<div class="fundo1 w3-display-container">
			

		      <div class="w3-content w3-white" style="max-width:450px; opacity: 0.95">

			      <div class="w3-center"><br>
			        <img src="../_imagens/logo.png" alt="Logo" style="width:30%" class="w3-circle w3-margin-top">
			      </div>

			      <form class="w3-container" action="./cadastro.php" method="POST">
							<div class="w3-section">
								<div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
									<div class="controls">
										<p><input class="w3-input" required type="text" placeholder="Nome" name="nome" value="<?php echo !empty($nome)?$nome: '';?>"></p>
										<?php if(!empty($nomeErro)): ?>
											<span class="help-inline"><?php echo $nomeErro;?></span>
										<?php endif;?>
									</div>
								</div>
								<div class="control-group <?php echo !empty($cpfErro)?'error ' : '';?>">
									<div class="controls">
										<p><input class="w3-input" required placeholder="CPF" type="text" name="cpf" maxlength="14" OnKeyPress="formatar('###.###.###-##', this)"
											value="<?php echo !empty($cpf)?$cpf: '';?>"></p>
										<?php if(!empty($cpfErro)): ?>
											<span class="help-inline"><?php echo $cpfErro;?></span>
										<?php endif;?>
									</div>
								</div>

								<div class="control-group <?php echo !empty($enderecoErro)?'error ': '';?>">
									<div class="controls">
										<p><input class="w3-input" type="text" required placeholder="Endereço" name="endereco" value="<?php echo !empty($endereco)?$endereco: '';?>"></p>
										<?php if(!empty($enderecoErro)): ?>
											<span class="help-inline"><?php echo $enderecoErro;?></span>
										<?php endif;?>
									</div>
								</div>

								<div class="control-group <?php echo !empty($telefoneErro)?'error ': '';?>">
									<div class="controls">
										<p><input class="w3-input" type="tel" required placeholder="Telefone  ex.:(00) 00000-0000" name="telefone" maxlength="15" value="<?php echo !empty($telefone)?$telefone: '';?>"></p>
										<?php if(!empty($telefoneErro)): ?>
											<span class="help-inline"><?php echo $telefoneErro;?></span>
										<?php endif;?>
									</div>
								</div>

								<div class="control-group <?php echo !empty($emailErro)?'error ': '';?>">
									<div class="controls">
										<p><input class="w3-input" type="text" required placeholder="Email" name="email" value="<?php echo !empty($email)?$email: '';?>"></p>
										<?php if(!empty($emailErro)): ?>
											<span class="help-inline"><?php echo $emailErro;?></span>
										<?php endif;?>
									</div>
								</div>

								<div class="control-group">
									<div class="controls">
										<input type="checkbox" id="isfunc" name="isfunc" class="w3-check" onclick="ativarEmpresa();" <?php echo ($isfunc)?'checked':''; ?>>Funcionário</input>
									</div>
								</div>
								<div id="elementosEmpresa" <?php echo (!$isfunc)?'style="display:none"':'';?> class="control-group <?php echo !empty($empresaErro)?'error ': '';?>">
									<div class="controls">
										<select class="w3-select" name="empresa">
											<option value="" disabled selected>Selecione uma Empresa</option>
											<?php 
												$pdo = Banco::conectar();
												$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
												$sql = "SELECT * FROM empresa ORDER BY razaoSocial ";
												$q = $pdo->prepare($sql);
												$q->execute();
												while($data = $q->fetch(PDO::FETCH_ASSOC)) {
												echo '<option value="' . $data['idEmpresa'] . '"';
												if($empresa == $data['idEmpresa'])
													echo ' selected';
												echo '>' . $data['razaoSocial'] . '</option>';
												}
												Banco::desconectar();
											?>
										</select>
										<?php if(!empty($empresaErro)): ?>
											<span class="help-inline"><?php echo $empresaErro;?></span>
										<?php endif;?>
									</div>
									<div class="controls">
										<p><input class="w3-input" type="text" placeholder="Funcao" name="funcao" value="<?php echo !empty($funcao)?$funcao: '';?>"></p>
										<?php if(!empty($funcaoErro)): ?>
											<span class="help-inline"><?php echo $funcaoErro;?></span>
										<?php endif;?>
									</div>
									<div class="controls">
										<p><input class="w3-input" type="text" placeholder="Salario" name="salario" value="<?php echo !empty($salario)?$salario: '';?>"></p>
										<?php if(!empty($salarioErro)): ?>
											<span class="help-inline"><?php echo $salarioErro;?></span>
										<?php endif;?>
									</div>
								</div>

								<div class="control-group <?php echo !empty($senhaErro)?'error ': '';?>">
									<div class="controls">
										<p><input class="w3-input" type="password" required placeholder="Senha" name="senha" value="<?php echo !empty($senha)?$senha: '';?>"></p>
										<?php if(!empty($senhaErro)): ?>
											<span class="help-inline"><?php echo $senhaErro;?></span>
										<?php endif;?>
									</div>
								</div>

								<div class="control-group <?php echo !empty($csenhaErro)?'error ': '';?>">
									<div class="controls">
										<p><input class="w3-input" type="password" required placeholder="Confirmar senha" name="csenha" value="<?php echo !empty($csenha)?$csenha: '';?>"></p>
										<?php if(!empty($csenhaErro)): ?>
											<span class="help-inline"><?php echo $csenhaErro;?></span>
										<?php endif;?>
									</div>
								</div>
							</div>

			        <div class="w3-margin-top">
			    	  	<button type="submit" class="w3-right w3-button w3-blue w3-hover-light-blue w3-round-large">Cadastrar</button>
			    	  	<a href="../index.php" type="button" class="w3-right w3-button w3-text-red w3-hover-red w3-round-large w3-margin-right">Cancelar</a><br>
			        </div> <br>

						</div>
					</form>
		    </div>
		</div>
	</body>
</html>