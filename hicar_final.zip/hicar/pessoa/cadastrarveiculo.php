<?php
  session_start();
  if(!isset($_SESSION['usuario'])) {
		header("Location: ../index.php");
  }
  $id = $_SESSION['usuario'];
  require '../banco.php';

  if(!empty($_POST)) {
    //Acompanha os erros de validação
    $modeloErro = null;
    $corErro    = null;
    $chassiErro = null;
    $placaErro  = null;
    $anoErro    = null;

    $modelo = $_POST['modelo'];
    $cor    = $_POST['cor'];
    $chassi = $_POST['chassi'];
    $placa  = $_POST['placa'];
    $ano    = $_POST['ano'];
    
    //Validaçao dos campos:
    $validacao = true;
    if(empty($modelo)) {
        $modeloErro = 'Por favor digite o seu modelo!';
        $validacao = false;
    }

    if(empty($cor)) {
        $corErro = 'Por favor escolha a cor!';
        $validacao = false;
    }

    if(empty($chassi)) {
        $chassiErro = 'Por favor digite o chassi';
        $validacao = false;
    } else {
      $pdo = Banco::conectar();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT COUNT(*) FROM veiculo WHERE chassi = '" . $chassi . "'";
      $q = $pdo->prepare($sql);
      $q->execute();
      $data = $q->fetch(PDO::FETCH_ASSOC);
      Banco::desconectar();
      if($data[0] > 0) {
        $placaErro = "Chassi já usado em outro veículo!";
        $validacao = false;
      }
    }
    
    if(empty($placa)) {
        $placaErro = 'Por favor digite a placa!';
        $validacao = false;
    } else {
      $pdo = Banco::conectar();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "SELECT COUNT(*) FROM veiculo WHERE placa = '" . $placa . "'";
      $q = $pdo->prepare($sql);
      $q->execute();
      $data = $q->fetch(PDO::FETCH_ASSOC);
      Banco::desconectar();
      if($data[0] > 0) {
        $placaErro = "Placa já usada em outro veículo!";
        $validacao = false;
      }
    }

    if(empty($ano)) {
        $anoErro = 'Por favor escolha o ano de fabricação!';
        $validacao = false;
    }     
            
    //Inserindo no Banco:
    if($validacao) {
      $pdo = Banco::conectar();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO veiculo (modelo, cor, chassi, placa, ano, idPessoa) VALUES(?,?,?,?,?,?)";
      $q = $pdo->prepare($sql);
      $q->execute(array($modelo,$cor,$chassi,$placa,$ano,$id));
      Banco::desconectar();
      header("Location: meusveiculos.php");
    }
  }
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Cadastro Carro</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../_css/login-cadastro.css" type="text/css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- Barra de Menu e Head-->
    <div class="w3-top">
      <div class="w3-bar w3-light-blue" id="myNavbar">
        <a href="../index.php"><img class="w3-image w3-bar-item" 
        src="../_imagens/logo.png" style="width:10%"></a>
        <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>

        <div class="w3-dropdown-hover w3-right w3-light-blue">
              <i class="material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white">person</i> 
              <div class="w3-dropdown-content w3-bar-block w3-border">
                <a href="perfil.php" class="w3-bar-item w3-button w3-hover-blue">Perfil</a>
                <a href="../logout.php" class="w3-bar-item w3-button w3-hover-blue">Sair</a>
              </div> 
        </div>

        <a href="../mensagem.php" class="w3-light-blue material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white w3-right"style="text-decoration: none">email</a>
        
        <a href="meusveiculos.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%">Meus Veículos<i class="w3-right material-icons">
        directions_car</i></a>
      </div>
    </div>
  </head>
	<body>
		<div class="fundo1 w3-display-container" style="height: 100%;">
      <div class="w3-content w3-white" style="max-width:450px; opacity: 0.95">
        <div class="w3-center"><br>
          <img src="../_imagens/logo.png" alt="Logo" style="width:30%" class="w3-circle w3-margin-top">
        </div>
        <form class="w3-container" action="cadastrarveiculo.php" method="POST">
          <div class="w3-section">
            <div class="control-group <?php echo !empty($modeloErro)?'error ' : '';?>">
						  <div class="controls">
                <p><input class="w3-input" type="text" placeholder="Modelo" name="modelo" value="<?php echo !empty($modelo)?$modelo: '';?>"></p>
                <?php if(!empty($modeloErro)): ?>
                  <span class="help-inline"><?php echo $modeloErro;?></span>
                <?php endif;?>
              </div>
            </div>
            <div class="control-group <?php echo !empty($corErro)?'error ' : '';?>">
						  <div class="controls">
                <select class="w3-select w3-text-gray w3-margin-top w3-opacity-min" style="background-color: white; margin-left: 4px" name="cor">
                  <option value="" disabled <?php echo empty($cor)?'selected':'';?>>Cor</option>
                  <option value="Branco" <?php echo ($cor=='Branco')?'selected':'';?> >Branco</option>
                  <option value="Preto" <?php echo ($cor=='Preto')?'selected':'';?> >Preto</option>
                  <option value="Cinza" <?php echo ($cor=='Cinza')?'selected':'';?> >Cinza</option>
                  <option value="Prata" <?php echo ($cor=='Prata')?'selected':'';?> >Prata</option>
                  <option value="Vermelho" <?php echo ($cor=='Vermelho')?'selected':'';?> >Vermelho</option>
                  <option value="Azul" <?php echo ($cor=='Azul')?'selected':'';?> >Azul</option>
                  <option value="Marrom" <?php echo ($cor=='Marrom')?'selected':'';?> >Marrom</option>
                  <option value="Verde" <?php echo ($cor=='Verde')?'selected':'';?> >Verde</option>
                  <option value="Dourado/Amarelo" <?php echo ($cor=='Dourado/Amarelo')?'selected':'';?> >Dourado/Amarelo</option>
                  <option value="Laranja" <?php echo ($cor=='Laranja')?'selected':'';?> >Laranja</option>
                  <option value="Bege" <?php echo ($cor=='Bege')?'selected':'';?> >Bege</option>
                  <option value="Outra" <?php echo ($cor=='Outra')?'selected':'';?> >Outra</option>
                </select>
                <?php if(!empty($corErro)): ?>
                  <span class="help-inline"><?php echo $corErro;?></span>
                <?php endif;?>
              </div>
            </div>
            <div class="control-group <?php echo !empty($chassiErro)?'error ' : '';?>">
						  <div class="controls">
                <p><input class="w3-input w3-margin-top" type="text" placeholder="Chassi" name="chassi" value="<?php echo !empty($chassi)?$chassi: '';?>"></p>
                <?php if(!empty($chassiErro)): ?>
                  <span class="help-inline"><?php echo $chassiErro;?></span>
                <?php endif;?>
              </div>
            </div>
            <div class="control-group <?php echo !empty($placaErro)?'error ' : '';?>">
						  <div class="controls">
                <p><input class="w3-input w3-margin-top" type="text" placeholder="Placa" name="placa" value="<?php echo !empty($placa)?$placa: '';?>"></p>
                <?php if(!empty($placaErro)): ?>
                  <span class="help-inline"><?php echo $placaErro;?></span>
                <?php endif;?>
              </div>
            </div>
            <div class="control-group <?php echo !empty($anoErro)?'error ' : '';?>">
						  <div class="controls">
                <select class="w3-select w3-text-gray w3-margin-top w3-opacity-min" style="background-color: white; margin-left: 4px" name="ano">
                  <option value="">Ano</option><option value="1950">1950 ou anterior</option><option value="1955">1955</option><option value="1960">1960</option><option value="1965">1965</option><option value="1970">1970</option><option value="1975">1975</option><option value="1980">1980</option><option value="1981">1981</option><option value="1982">1982</option><option value="1983">1983</option><option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option>
                </select>
                <?php if(!empty($anoErro)): ?>
                  <span class="help-inline"><?php echo $anoErro;?></span>
                <?php endif;?>
              </div>
            </div>
            <div class="w3-margin-top">
              <button class="w3-right w3-button w3-blue w3-hover-light-blue w3-round-large" type="submit">Cadastrar</button>
              <a href="meusveiculos.php" type="button" class="w3-right w3-button w3-text-red w3-hover-red w3-round-large w3-margin-right">Cancelar</a><br>
            </div> <br>  
          </div>
        </form>
      </div>
		</div>
	</body>
</html>