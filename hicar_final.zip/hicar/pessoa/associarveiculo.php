<?php
  session_start();
  if(!isset($_SESSION['usuario'])) {
		header("Location: ../index.php");
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Associar Veículo</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="../_css/estilo.css" type="text/css"/>
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

        <!-- Barra de Menu e Head-->
       <div class="w3-top">
          <div class="w3-bar w3-light-blue" id="myNavbar">
            <a href="../index.php"><img class="w3-image w3-bar-item" 
            src="../_imagens/logo.png" style="width:10%"></a>
            <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>

            <div class="w3-dropdown-hover w3-right w3-light-blue">
                  <i class="material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white">person</i> 
                  <div class="w3-dropdown-content w3-bar-block w3-border">
                    <a href="perfil.php" class="w3-bar-item w3-button w3-hover-blue">Perfil</a>
                    <a href="../logout.php" class="w3-bar-item w3-button w3-hover-blue">Sair</a>
                  </div> 
            </div>

            <a href="../mensagem.php" class="w3-light-blue material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white w3-right"style="text-decoration: none">email</a>
            
            <a href="meusveiculos.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%">Meus Veículos<i class="w3-right material-icons">
            directions_car</i></a>
          </div>
        </div>
    </head>

    <!--Breadcrumbs -->
    <ul class="breadcrumb" style="margin-top:-1%">
        <li><a href="../index.php">Home</a></li>
        <li><a href="../user.php">Usuário</a></li>
        <li><a href="meusveiculos.php">Meus Veículos</a></li>
        <li>Associar Veículos</li>
    </ul>


    <body style="padding-top: 100px">

        <div class="w3-container w3-card-4" style="margin-left: 400px; margin-right: 400px; min-height:80%; padding-top: 50px">
            <i class="material-icons w3-center w3-left" style="font-size:100px; margin-top:-1%; margin-left:10%">directions_car</i>
            <pre class="w3-center">MODELO || COR || ANO</pre>
            <pre class="w3-center">ABC-0000</pre>
            <pre class="w3-center" style="margin-left:25%">CHASSI</pre>
            <hr>

            <form class="w3-container">
                <div class="w3-section">
                    <input class="w3-input" type="text" placeholder="CPF do Destinatário" name="cpfdestinatario">
                    <input class="w3-input w3-margin-top" type="text" placeholder="E-mail" name="email">
                </div>

                <div class="w3-margin-top">
                    <a onclick="document.getElementById('id01').style.display='block'" class="w3-right w3-button w3-blue w3-hover-light-blue w3-round-large" type="submit">Transferir</a>
                    <a href="meusveiculos.php" type="button" class="w3-right w3-button w3-text-red w3-hover-red w3-round-large w3-margin-right">Cancelar</a><br>
                </div> <br>
            </form>


            <div id="id01" class="w3-modal">
                <div class="w3-modal-content w3-card" style="max-width:520px; margin-top: 100px">
            
                    <div class="w3-container w3-center w3-margin-left"><br>
                        <p class="w3-left">Nome do Destinatário</p>

                        <form class="w3-right">
                            Confirma a transferência?<br>
                            <input type="password" placeholder="Senha" name="psw">
                            
                            <div class="w3-container w3-border-top w3-padding-16 w3-margin-top">
                                <a onclick="document.getElementById('id01').style.display='block'" class="w3-right w3-button w3-blue w3-hover-blue w3-round-large" type="submit">Transferir</a>
                                <span onclick="document.getElementById('id01').style.display='none'" class="w3-right w3-button w3-red w3-hover-red w3-round-large w3-margin-right">Cancelar</span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <footer class="w3-container w3-center w3-dark-grey w3-margin-top">
        <a href="https://www.facebook.com/" style="text-decoration: none" target="_blank" class="fa fa-facebook-square w3-text-color-white w3-xxlarge w3-padding"></a>
        <a href="https://www.instagram.com/" style="text-decoration: none" target="_blank" class="fa fa-instagram w3-text-color-white w3-margin-top w3-xxlarge"></a>
        <a href="https://www.linkedin.com/" style="text-decoration: none" target="_blank" class="fa fa-linkedin w3-text-color-white w3-xxlarge w3-padding"></a>

        <a href="#"><i class="fa fa-chevron-circle-up w3-right w3-xxlarge" style="margin-top:4%; margin-right:2%;" alt="Início"></i></a>
            <p class="w3-center w3-align">© 2018 Hi-Car All Rights Reserved</p><br/>
        </footer>
    </body>

    <script>
        function mudarEstado(el1, el2){
            var botao = document.getElementById(el2);
            var div = document.getElementById(el2).style.display;
            if(div == "none"){
                document.getElementById(el2).style.display = 'block';
                document.getElementById(el1).innerHTML='keyboard_arrow_down';
            }
            else{
                document.getElementById(el2).style.display = 'none';
                document.getElementById(el1).innerHTML='keyboard_arrow_right';
            }
        }

        function alertTransferir() {

        }
    </script>
</html>