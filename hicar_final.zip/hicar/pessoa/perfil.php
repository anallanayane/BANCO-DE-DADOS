<?php 
	session_start();
  	if(!isset($_SESSION['usuario'])) {
		header("Location: ../index.php");
	}
	require '../banco.php';

	$id = $_SESSION['usuario'];
	
	if ( null==$id ) {
	  header("Location: ../index.php");
	}
	
	if ( !empty($_POST)) {
    
		//Acompanha os erros de validação
		$nomeErro     = null;
		$cpfErro      = null;
		$emailErro    = null;
		$telefoneErro = null;
		$enderecoErro = null;
		
		$nome     = $_POST['nome'];
		$cpf      = $_POST['cpf'];
		$email    = $_POST['email'];
		$telefone = $_POST['telefone'];
		$endereco = $_POST['endereco'];
		
		//Validaçao dos campos:
		$validacao = true;
		if(empty($nome))
		{
		    $nomeErro = 'Por favor digite o seu nome!';
		    $validacao = false;
		}

		if(empty($cpf))
		{
		    $cpfErro = 'Por favor digite o seu CPF!';
		    $validacao = false;
		}

		if(empty($email))
		{
		    $emailErro = 'Por favor digite o endereço de email';
		    $validacao = false;
		}
		elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) 
		{
		    $emailError = 'Por favor digite um endereço de email válido!';
		    $validacao = false;
		}

		if(empty($telefone))
		{
		    $telefoneErro = 'Por favor digite o número do telefone!';
		    $validacao = false;
		}

		if(empty($endereco))
		{
		    $enderecoErro = 'Por favor digite o seu endereço!';
		    $validacao = false;
		}        
		        		
		// update data
		if ($validacao) {
			$pdo = Banco::conectar();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$sql = "UPDATE pessoa  set nome = ?, cpf = ?, email = ?, telefone = ?, endereco = ? WHERE idPessoa = ?";
			$q = $pdo->prepare($sql);
			$q->execute(array($nome, $cpf, $email, $telefone, $endereco, $id));
			Banco::desconectar();
			header("Location: ../index.php");
		}
	}	else {
		$pdo = Banco::conectar();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM pessoa where idPessoa = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data = $q->fetch(PDO::FETCH_ASSOC);
		$nome = $data['nome'];
		$cpf = $data['cpf'];
		$email = $data['email'];
		$telefone = $data['telefone'];
		$endereco = $data['endereco'];
		Banco::desconectar();
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Perfil</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../_css/login-cadastro.css" type="text/css"/>
		<link rel="stylesheet" href="../_css/estilo.css" type="text/css"/>
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

		<div class="w3-top">
			<div class="w3-bar w3-light-blue" id="myNavbar">
			    <a href="../index.php"><img class="w3-image w3-bar-item" 
			    src="../_imagens/logo.png" style="width:10%"></a>
			    <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>
			</div>
		</div>
	</head>

	 <!-- Barra de Menu e Head-->
    <div class="w3-top">
      <div class="w3-bar w3-light-blue" id="myNavbar">
        <a href="../index.php"><img class="w3-image w3-bar-item" 
        src="../_imagens/logo.png" style="width:10%"></a>
        <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>

        <div class="w3-dropdown-hover w3-right w3-light-blue">
              <i class="material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white">person</i> 
              <div class="w3-dropdown-content w3-bar-block w3-border">
			  <a href="../logout.php" class="w3-bar-item w3-button w3-hover-blue">Sair</a>
              </div> 
        </div>

        <a href="../mensagem.php" class="w3-light-blue material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white w3-right"style="text-decoration: none">email</a>
        
        <a href="meusveiculos.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%">Meus Veículos<i class="w3-right material-icons">
        directions_car</i></a>
      </div>
    </div>
  </head>

<!-- Breadcrumbs -->
	<ul class="breadcrumb" style="margin-top:6%">
      <li><a href="../index.php">Home</a></li>
      <li><a href="../user.php">Usuário</a></li>
      <li>Pefil</li>
	</ul>

	<body>
	<div id="Perfil" class=" w3-display-container w3-padding" style="margin-top: 0%">
      <div class="w3-content w3-margin-top w3-padding" style="max-width:50%; opacity: 0.95;">
        <div class="w3-content w3-container w3-center w3-padding-64 w3-align w3-margin-top" id="agendar">
		      <form class="w3-container" action="perfil.php" method="post">
		        <div class="w3-section">
							<div class="control-group <?php echo !empty($nomeErro)?'error ' : '';?>">
								<div class="controls">
										<input class="w3-input" size= "50" name="nome" type="text" placeholder="Nome" required="" value="<?php echo !empty($nome)?$nome: '';?>">
										<?php if(!empty($nomeErro)): ?>
												<span class="help-inline"><?php echo $nomeErro;?></span>
										<?php endif;?>
								</div>
							</div>
							<div class="control-group <?php echo !empty($cpfErro)?'error ' : '';?>">
								<div class="controls">
										<input class="w3-input" size= "15" name="cpf" type="text" placeholder="CPF" required="" value="<?php echo !empty($cpf)?$cpf: '';?>">
										<?php if(!empty($cpfErro)): ?>
												<span class="help-inline"><?php echo $cpfErro;?></span>
										<?php endif;?>
								</div>
							</div>

							<div class="control-group <?php echo !empty($emailErro)?'error ': '';?>">
								<div class="controls">
										<input class="w3-input" size="40" name="email" type="text" placeholder="Email" required="" value="<?php echo !empty($email)?$email: '';?>">
										<?php if(!empty($emailErro)): ?>
										<span class="help-inline"><?php echo $emailErro;?></span>
										<?php endif;?>
								</div>
							</div>

							<div class="control-group <?php echo !empty($telefoneErro)?'error ': '';?>">
								<div class="controls">
										<input class="w3-input" size="35" name="telefone" type="text" placeholder="Telefone" required="" value="<?php echo !empty($telefone)?$telefone: '';?>">
										<?php if(!empty($emailErro)): ?>
										<span class="help-inline"><?php echo $telefoneErro;?></span>
										<?php endif;?>
								</div>
							</div>

							<div class="control-group <?php echo !empty($enderecoErro)?'error ': '';?>">
								<div class="controls">
										<input class="w3-input" size="80" name="endereco" type="text" placeholder="Endereço" required="" value="<?php echo !empty($endereco)?$endereco: '';?>">
										<?php if(!empty($emailErro)): ?>
										<span class="help-inline"><?php echo $enderecoErro;?></span>
										<?php endif;?>
								</div>
							</div>

							<br/>
		      	</div>

		        <div class="w3-margin-top">
		    	  	<button class="w3-right w3-button w3-blue w3-hover-light-blue w3-round-large" type="submit">Salvar Alterações</button>
		    	  	<a href="../user.php" type="button" class="w3-right w3-button w3-text-red w3-hover-red w3-round-large w3-margin-right">Cancelar</a><br>
		        </div> <br>
		          
			    </div>
			  </form>
		    </div>
		</div>
		
		<!-- Footer -->
	    <footer class="w3-container w3-center w3-dark-grey">
	      <a href="https://www.facebook.com/" style="text-decoration: none" target="_blank" class="fa fa-facebook-square w3-text-color-white w3-xxlarge w3-padding"></a>
	      <a href="https://www.instagram.com/" style="text-decoration: none" target="_blank" class="fa fa-instagram w3-text-color-white w3-margin-top w3-xxlarge"></a>
	      <a href="https://www.linkedin.com/" style="text-decoration: none" target="_blank" class="fa fa-linkedin w3-text-color-white w3-xxlarge w3-padding"></a>

	      <a href="#Perfil"><i class="fa fa-chevron-circle-up w3-right w3-xxlarge" style="margin-top:4%; margin-right:2%;" alt="Início"></i></a>
	        <p class="w3-center w3-align">© 2018 Hi-Car All Rights Reserved</p><br/>
	    </footer>
	</body>
</html>