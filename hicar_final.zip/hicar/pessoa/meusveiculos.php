<?php
    ini_set('display_errors', 1);
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    $id = $_SESSION['usuario'];
    if($id==null)
        header("Location: ../index.php");
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <title>Meus Veículos</title>
        <?php include '../cabecalho_cadastros.php'; ?>
    </head>

    <!--Breadcrumbs -->
    <ul class="breadcrumb" style="margin-top:-3%">
        <li><a href="../index.php">Home</a></li>
        <?php 
          if($funcionario) {
            echo '<li><a href="../user.php">Funcionário</a></li>';
          } else {
            echo '<li><a href="../user.php">Usuário</a></li>';
          }
        ?>
        <li>Meus Veículos</li>
    </ul>

    <!--Meus Veiculos -->
    <body style="padding-top: 180px">

        <div class="w3-container w3-blue w3-padding " style="margin-left: 400px; margin-right: 400px; height: auto; margin-top:3%">
            <a href="../user.php" class="material-icons w3-text-white w3-padding" style="text-decoration: none; margin-top:1%">arrow_back</a><span class="w3-center w3-xlarge" style="margin-left:5%; margin-bottom:10%">Meus Veículos</span>
            <a href="../user.php" class="material-icons w3-text-white w3-padding w3-right" style=" text-decoration: none; margin-top:1%">close</a></div>
        
            <i class="material-icons w3-center w3-left" style="font-size:100px; margin-top:3%; margin-left:35%; margin-bottom:5%">directions_car</i>
             <h6 style="margin-left:50%; margin-top:5%">Adicionar novo veículo<a style="text-decoration: none; margin-top:3%" href="cadastrarveiculo.php" class="material-icons w3-text-blue w3-xxlarg">add_circle</a></h6>

            <div class="w3-content w3-card" style="width:500px">
                <ul style="list-style-type: none; padding: 25px; margin-top:10%">
                    <?php 
                        $pdo = Banco::conectar();
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        $sql = "SELECT * FROM veiculo WHERE idPessoa = " . $id;
                        $q = $pdo->prepare($sql);
                        $q->execute();
                        if(!$data)
                            echo '<li><div class="w3-display-container">Nenhum veículo cadastrado</div></li>';
                        while($data = $q->fetch(PDO::FETCH_ASSOC)) {
                            echo 
                            '<li>
                                <div class="w3-display-container">
                                    <span class="w3-display-topmiddle w3-large w3-text-blue">' . $data['modelo'] . '</span><br>
                                    <span class="w3-display-right w3-small">Cor: '             . $data['cor'] . '</span><br>
                                    <span class="w3-display-bottomright w3-small">Ano: '       . $data['ano'] . '</span><br>
                                    <span class="w3-display-left w3-small">Placa: '            . $data['placa'] . '</span><br>
                                    <span class="w3-display-bottomleft w3-small">Chassi: '     . $data['chassi'] . '</span>
        
                                    <div class="w3-dropdown-hover w3-display-topright">
                                        <a onclick="dropdown()" class="w3-button material-icons">keyboard_arrow_down</a>
                                        <div class="w3-dropdown-content w3-bar-block w3-border">
                                            <a href="agendamento.php?veiculo='     . $data['idVeiculo'] . '" class="w3-bar-item w3-button">Agendar Serviço</a>
                                            <a href="servicosativos.php?veiculo='  . $data['idVeiculo'] . '" class="w3-bar-item w3-button">Serviços Ativo</a>
                                            <a href="historico.php?veiculo='       . $data['idVeiculo'] . '" class="w3-bar-item w3-button">Histórico</a>
                                            <a href="associarveiculo.php?veiculo=' . $data['idVeiculo'] . '" class="w3-bar-item w3-button">Associar Veículo</a>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <hr>';
                        }
                        Banco::desconectar();
                    ?>
                </ul>
            </div>
        </div>

        
        <!-- Footer -->
        <footer class="w3-container w3-center w3-dark-grey" style="margin-top:5%">
        <a href="https://www.facebook.com/" style="text-decoration: none" target="_blank" class="fa fa-facebook-square w3-text-color-white w3-xxlarge w3-padding"></a>
        <a href="https://www.instagram.com/" style="text-decoration: none" target="_blank" class="fa fa-instagram w3-text-color-white w3-margin-top w3-xxlarge"></a>
        <a href="https://www.linkedin.com/" style="text-decoration: none" target="_blank" class="fa fa-linkedin w3-text-color-white w3-xxlarge w3-padding"></a>

        <a href="#"><i class="fa fa-chevron-circle-up w3-right w3-xxlarge" style="margin-top:4%; margin-right:2%;" alt="Início"></i></a>
            <p class="w3-center w3-align">© 2018 Hi-Car All Rights Reserved</p><br/>
        </footer>
    </body>
</html>