<?php
  session_start();
  if(!isset($_SESSION['usuario'])) {
		header("Location: index.php");
	}
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Mensagem</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="_css/estilo.css" type="text/css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- Barra de Menu e Head-->
    <div class="w3-top">
      <div class="w3-bar w3-light-blue" id="myNavbar">
        <a href="index.php"><img class="w3-image w3-bar-item" 
        src="_imagens/logo.png" style="width:10%"></a>
        <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>

        <div class="w3-dropdown-hover w3-right w3-light-blue">
              <i class="material-icons w3-xxlarge w3-padding-large w3-margin-top w3-text-white">person</i> 
              <div class="w3-dropdown-content w3-bar-block w3-border">
                <a href="./pessoa/perfil.php" class="w3-bar-item w3-button w3-hover-blue">Perfil</a>
                <a href="logout.php" class="w3-bar-item w3-button w3-hover-blue">Sair</a>
              </div> 
        </div>

        <a href="./pessoa/meusveiculos.php" class="w3-btn w3-blue w3-round-large w3-right" style="max-width:15%; margin-top:2%">Meus Veículos <i class="w3-right material-icons">
        directions_car</i></a>
      </div>
    </div>
</head>

<!-- Breadcrumbs -->
<ul class="breadcrumb" style="margin-top:6%">
      <li><a href="index.php">Home</a></li>
      <li><a href="user.php">Usuário</a></li>
      <li>Mensagens</li>
</ul>

<body>

    <!-- Side Navigation -->
    <nav class="w3-sidebar w3-bar-block w3-collapse w3-white w3-animate-left w3-card" style="z-index:3;width:320px; margin-top:-1%" id="mySidebar">
      <a href="javascript:void(0)" onclick="w3_close()" title="Close Sidemenu" 
      class="w3-bar-item w3-button w3-hide-large w3-large">Fechar <i class="material-icons">close</i></a>
      
      <a href="javascript:void(0)" class="w3-bar-item w3-button w3-blue-grey  w3-hover-black w3-left-align w3-large" onclick="document.getElementById('id01').style.display='block'">Nova Mensagem <i class="material-icons w3-padding">edit</i></a>
     
      <a id="myBtn" onclick="myFunc('Demo1')" href="javascript:void(0)" class="w3-bar-item w3-button w3-blue w3-large"><i class="fa fa-inbox w3-margin-right"></i><span class"w3-margin-top">Caixa de Entrada (3)</span><i class="w3-margin-left fa fa-caret-down"></i></a>
      
      <div id="Demo1" class="w3-hide w3-animate-left">
        <a href="javascript:void(0)" class="w3-bar-item w3-button w3-border-bottom test w3-hover-light-grey" onclick="openMail('Funcionario2');w3_close();"   id="firstTab">
          <div class="w3-container">
            <i class="material-icons w3-left w3-text-gray" style="margin-top:2px">person</i><span class="w3-opacity w3-large"style="margin-left:2%"> Funcionário 2</span>
            <span class="w3-right"> 11:30</span>
            <h6>Assunto: Serviço Concluído</h6>
            <p>Olá, gostaria de informá-lo que o serviço do seu carro...</p>
          </div>
        </a>

         <a href="javascript:void(0)" class="w3-bar-item w3-button w3-border-bottom test w3-hover-light-grey" onclick="openMail('Mecanico1');w3_close();">
          <div class="w3-container"> 
            <i class="material-icons w3-left w3-text-gray" style="margin-top:2px">person</i><span class="w3-opacity w3-large style="margin-left:2%""> Mecânico 1</span>
            <span class="w3-right"> 09:30</span>
            <h6>Assunto: Troca de Peça</h6>
            <p>Verificamos que a peça X...</p>
          </div>
        </a>

        <a href="javascript:void(0)" class="w3-bar-item w3-button w3-border-bottom test w3-hover-light-grey" onclick="openMail('Funcionario1');
        w3_close();">
          <div class="w3-container">
            <i class="material-icons w3-left w3-text-gray" style="margin-top:2px">person</i><span class="w3-opacity w3-large" style="margin-left:2%">Funcionário 1</span>
            <span class="w3-right"> 09:00</span>
            <h6>Assunto: Agendamento Confirmado</h6>
            <p>O agendamento do serviço do seu veículo...</p>
          </div>
        </a>
      </div>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-paper-plane w3-margin-right"></i>Enviadas</a>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-hourglass-end w3-margin-right"></i>Rascunhos</a>
      <a href="#" class="w3-bar-item w3-button"><i class="fa fa-trash w3-marghin-right"></i> Lixeira</a>
    </nav>

    <!-- Modal para "Nova Mensagem" -->
    <div class="w3-modal" style="z-index:4" id="id01">
      <div class="w3-modal-content w3-animate-zoom">
        <div class="w3-container w3-padding w3-blue">
           <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-right w3-xxlarge"><i class="fa fa-remove"></i></span>
          <h2>Enviar Mensagem</h2>
        </div>
        <div class="w3-panel">
          <label>Para</label>
          <input class="w3-input w3-border w3-margin-bottom" type="text">
          <label>Assunto</label>
          <input class="w3-input w3-border w3-margin-bottom" type="text">
          <input class="w3-input w3-border w3-margin-bottom" style="height:150px" placeholder="Escreva sua mensagem aqui">
          <div class="w3-section">
            <a class="w3-button w3-red" onclick="document.getElementById('id01').style.display='none'">Cancelar  <i class="fa fa-remove"></i></a>
            <a class="w3-button w3-blue w3-right" onclick="document.getElementById('id01').style.display='none'">Enviar  <i class="fa fa-paper-plane"></i></a> 
          </div>    
        </div>
      </div>
    </div>

    <!-- Overlay effect when opening the side navigation on small screens -->
    <div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="Close Sidemenu" id="myOverlay"></div>

    <!-- Page content -->
    <div class="w3-main" style="margin-left:320px;">
    <i class="fa fa-bars w3-button w3-white w3-hide-large w3-xlarge w3-margin-top" onclick="w3_open()"></i>
    <a href="javascript:void(0)" class="w3-hide-large w3-red w3-button w3-right w3-margin-top w3-margin-right" onclick="document.getElementById('id01').style.display='block'"><i class="fa fa-pencil"></i></a>

    <div id="Funcionario2" class="w3-container person">
      <br>
      <i class="material-icons w3-jumbo" style="margin-top:10%">person</i>
      <h5 class="w3-opacity w3-padding">Assunto: Serviço Concluído</h5>
      <h4><i class="fa fa-clock-o"></i> Funcionário 2, 20 de Junho, 2018.</h4>
      <a  href="javascript:void(0)"class="w3-button" onclick="document.getElementById('id01').style.display='block'">Responder<i class="w3-padding fa fa-mail-reply"></i></a>
      <a class="w3-button" href="#">Encaminhar<i class="w3-padding fa fa-arrow-right"></i></a>
      <hr>
      <p>Olá, </p>
      <p>Gostaria de informá-lo que o serviço do seu carro foi concluído e estamos aguarando o senhor em nossa loja.</p>
      <p>Funcionario 2</p>
    </div>

    <div id="Mecanico1" class="w3-container person">
      <br>
      <i class="material-icons w3-jumbo" style="margin-top:10%">person</i>
      <h5 class="w3-opacity">Assunto: Troca de Peça</h5>
      <h4><i class="fa fa-clock-o w3-padding"></i> Mecanico 1, 20 de Junhi, 2018.</h4>
      <a  href="javascript:void(0)"class="w3-button" onclick="document.getElementById('id01').style.display='block'">Responder<i class="w3-padding fa fa-mail-reply"></i></a>
      <a class="w3-button">Encaminhar<i class="w3-padding fa fa-arrow-right"></i></a>
      <hr>
      <p>Verificamos que a peça X necessita ser trocada para um melhor funcionamento do seu carro.</p>
      <p>Necessitamos da sua autorização para que possamos dar continuidade no serviço. O senhor nos autoriza a troca da peça?</p>
      <p>Para mais informações e autorização do serviço, por favor entre em contato conosco.</p>
      <p>Aguardamos sua resposta.</p>
      <p>Mecanico 1</p>
    </div>

    <div id="Funcionario1" class="w3-container person">
      <br>
      <i class="material-icons w3-jumbo" style="margin-top:10%">person</i> 
      <h5 class="w3-opacity">Assunto: Agendamento Confirmado</h5>
      <h4><i class="fa fa-clock-o w3-padding"></i>Funcionario 1, 15 de Junho, 2018.</h4>
      <a href="javascript:void(0)"class="w3-button" onclick="document.getElementById('id01').style.display='block'">Responder<i class="w3-padding fa fa-mail-reply"></i></a>
      <a class="w3-button">Encaminhar<i class="w3-padding fa fa-arrow-right"></i></a>
      <hr>
      <p>O agendamento do serviço do seu veículo foi confirmardo para o dia 20 de Junho às 09:00 horas</p>
      <p>Estamos lhe aguardando para bem atendê-lo em nossa loja</p>
      <p>Funcionario 1</p>
    </div>
         
    </div>

    <script>
    var openInbox = document.getElementById("myBtn");
    openInbox.click();

    function w3_open() {
        document.getElementById("mySidebar").style.display = "block";
        document.getElementById("myOverlay").style.display = "block";
    }
    function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
        document.getElementById("myOverlay").style.display = "none";
    }

    function myFunc(id) {
        var x = document.getElementById(id);
        if (x.className.indexOf("w3-show") == -1) {
            x.className += " w3-show"; 
            x.previousElementSibling.className += " w3-red";
        } else { 
            x.className = x.className.replace(" w3-show", "");
            x.previousElementSibling.className = 
            x.previousElementSibling.className.replace(" w3-red", "");
        }
    }

    openMail("Funcionario2")
    function openMail(personName) {
        var i;
        var x = document.getElementsByClassName("person");
        for (i = 0; i < x.length; i++) {
           x[i].style.display = "none";
        }
        x = document.getElementsByClassName("test");
        for (i = 0; i < x.length; i++) {
           x[i].className = x[i].className.replace(" w3-light-grey", "");
        }
        document.getElementById(personName).style.display = "block";
        event.currentTarget.className += " w3-light-grey";
    }
    </script>

    <script>
    var openTab = document.getElementById("firstTab");
    openTab.click();
    </script>

    </body>
</html> 