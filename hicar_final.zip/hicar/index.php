<?php
  session_start();
  if(isset($_SESSION['usuario']))
    header("Location: user.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
    <title>Hi-Car</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="_css/estilo.css" type="text/css"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">


    <!--barra topo -->
		<div class="w3-top">
			<div class="w3-bar w3-light-blue" id="myNavbar">
			    <a href="index.php"><img class="w3-image w3-bar-item" 
			    src="_imagens/logo.png" style="width:10%"></a>
			    <span class="w3-bar-item w3-text-white w3-xxlarge">Hi-Car</span>
				<div class="w3-text-white w3-display-right w3-margin-bottom">
			        <a href="#home" class="w3-bar-item w3-button w3-hover-blue w3-round-large">Home</a>
			        <a href="#sobre" class="w3-bar-item w3-button w3-hover-blue w3-round-large"> Sobre</a>
			        <a href="#portfolio" class="w3-bar-item w3-button w3-hover-blue w3-round-large"> Portfolio</a>
			        <a href="#contato" class="w3-bar-item w3-button w3-hover-blue w3-round-large"> Contato</a>
			        <a href="login.php" class="w3-bar-item w3-blue w3-button w3-hover-blue w3-round-large w3-margin-right">Login</a>
			        <a href="#" class="w3-bar-item w3-button w3-hover-blue w3-round-large w3-margin-right"> 
			        	<i class="fa fa-search w3-color-blue"></i> 
			        </a>
			    </div>
			</div>
		</div>
	</head>

	<body>
  <!-- slide-show Imagens -->
		<div class="w3-content w3-display-container" style="max-width:100%; height:auto" id="home">
		  <img class="mySlides w3-image" src="_imagens/app.jpeg" alt="hi-car" style="max-width:100%; height:auto">
		  <img class="mySlides w3-image" src="_imagens/mec2.jpg" alt="mecacnico atualizado" style="max-width:100%; height:auto;">
		  <img class="mySlides w3-image" src="_imagens/mecanica.jpg" alt="trabalho eficaz" style="max-width:100%; height:auto;">
		  <img class="mySlides w3-image" src="_imagens/cliente.jpg" alt="cliente satisfeito" style="max-width:100%; height:auto;">
		  <div class="w3-center w3-container w3-section w3-large w3-text-white w3-display-bottommiddle" style="max-width:100%; height:auto;">
		    <div class="w3-left w3-hover-text-khaki" onclick="plusDivs(-1)">&#10094;</div>
		    <div class="w3-right w3-hover-text-khaki" onclick="plusDivs(1)">&#10095;</div>
		    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(1)"></span>
		    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(2)"></span>
		    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(3)"></span>
		    <span class="w3-badge demo w3-border w3-transparent w3-hover-white" onclick="currentDiv(4)"></span>
		  </div>
		</div>

       <script>
		var slideIndex = 1;
		showDivs(slideIndex);

		function plusDivs(n) {
		  showDivs(slideIndex += n);
		}

		function currentDiv(n) {
		  showDivs(slideIndex = n);
		}

		function showDivs(n) {
		  var i;
		  var x = document.getElementsByClassName("mySlides");
		  var dots = document.getElementsByClassName("demo");
		  if (n > x.length) {slideIndex = 1}    
		  if (n < 1) {slideIndex = x.length}
		  for (i = 0; i < x.length; i++) {
		     x[i].style.display = "none";  
	  	  }
		  for (i = 0; i < dots.length; i++) {
		     dots[i].className = dots[i].className.replace(" w3-white", "");
		  }
		  x[slideIndex-1].style.display = "block";  
		  dots[slideIndex-1].className += " w3-white";
		}
	</script>

	  <!-- Container (About Section) -->
    <div class="w3-content w3-container w3-center w3-padding-64 w3-align" id="sobre">
      <h3 class="w3-center w3-xxlarge">Hi-Car</h3>
        <p class="w3-center w3-align" style="font-family: monospace; margin-left:20%; margin-right:20%">
         O Hi-Car é uma plataforma de gerenciamento de serviços 
    	   para concessionárias criado com o objetivo de melhorar 
	       as atividades oferecidas aos proprietários dos veículos, 
	       visando aproximar as empresas de seus clientes.
		    </p>
    </div>
	
	 <!-- Second Parallax Image with Portfolio Text -->
    <div id="portfolio" class="bgimg2 w3-display-container w3-opacity-min">
        <div class="w3-display-middle">
          <span class="w3-xxlarge w3-text-white w3-wide w3-image">PORTFOLIO</span>
        </div>
      </div>
  
    <div class="w3-row w3-center w3-dark-grey w3-padding-16">
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">14+</span><br>
        PARCEIROS
      </div>
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">10+</span><br>
        PROJETOS PRONTOS
      </div>
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">33+</span><br>
        CLIENTES SATISFEITOS
      </div>
      <div class="w3-quarter w3-section">
        <span class="w3-xlarge">80+</span><br>
        REUNIÕES
      </div>
    </div>
    
  <!-- Container (Portfolio Section) -->
  <div class="w3-content w3-container">
    <h3 class="w3-center w3-xlarge">Empresas Associadas: </h3>
    <br>
    <!-- Responsive Grid. Four columns on tablets, laptops and desktops. Will stack on mobile devices/small screens (100% width) -->
    <div class="w3-row-padding w3-center">
  
      <div class="w3-col m3 w3-image">
        <img src="_imagens/chevrolet.jpeg" style="max-width:100%; height:50%; " onclick="onClick(this)" class="w3-hover-opacity" alt="Chevrolet">
      </div>

      <div class="w3-col m3 w3-image">
        <img src="_imagens/volkswagen.jpeg" style="max-width:80%; height:auto;" onclick="onClick(this)" class="w3-hover-opacity" alt="Volkswagen">
      </div>

      <div class="w3-col m3 w3-image w3-margin-top">
        <img src="_imagens/toyota.jpg" style="max-width:100%; min-height:100%;" onclick="onClick(this)" class="w3-hover-opacity" alt="Toyota">
      </div>

      <div class="w3-col m3 w3-third w3-container w3-image w3-margin-top w3-padding-24">
        <img src="_imagens/ford.jpeg" style="max-width:100%; height:auto;" onclick="onClick(this)" class="w3-hover-opacity" alt="Ford">
      </div>

      <button class="w3-button w3-padding-large w3-blue w3-margin-bottom" style="margin-top:128px">CARREGUE MAIS</button>
    </div>
  </div>

<!-- Container (Contact Section) -->
  <div class="w3-container w3-light-grey" id="contato">  
    <div class="w3-row w3-section">
      <div class="w3-col m5 w3-panel w3-leftt w3-margin-left" style="margin-top:2%">
      <!-- Add Google Maps -->
      <div id="googleMap" style="max-width:80%;height:400px; margin-left:8%"></div>

<script>
function myMap() {
var mapProp= {
    center:new google.maps.LatLng(-5.8323987, -35.2054445),
    zoom:10,
};
var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=
AIzaSyAFgsQdSWE171NyNC8Q8S1UdwUzFohSE3A
&callback=myMap"></script>
  </div>
<!-- Formulario de Contato -->      
  <form action="/action_page.php" class="w3-container w3-card-4 w3-light-grey w3-text-blue w3-right w3-padding w3-col m5 w3-row"
   style="margin-right:6%; margin-top:2%">
    <h2 class="w3-center">Contato</h2>

    <div class="w3-row w3-section">
      <div class="w3-col" style="width:50px"><i class="material-icons w3-xxlarge">person</i></div>
        <div class="w3-rest">
          <input class="w3-input w3-border" name="first" type="text" placeholder="Nome">
        </div>
    </div>

    <div class="w3-row w3-section">
      <div class="w3-col" style="width:50px"><i class="material-icons w3-xxlarge">email</i></div>
        <div class="w3-rest">
          <input class="w3-input w3-border" name="email" type="text" placeholder="Email">
        </div>
        </div>

        <div class="w3-row w3-section">
          <div class="w3-col" style="width:50px;"><i class="material-icons w3-xxlarge">edit</i></div>
            <div class="w3-rest">
              <input class="w3-input w3-border" name="message" type="text" placeholder="Menssagem" style="height:100px">
            </div>
        </div>

        <button class="w3-button w3-blue w3-right w3-section" type="submit">
          <i class="fa fa-paper-plane"></i> ENVIAR MENSAGEM
        </button>
  </form>
  <div class="w3-col m8 w3-panel w3-text-gray" style="margin-left:4%">
    <div class="w3-large w3-margin-bottom ">
      <i class="material-icons w3-hover-text-black w3-xlarge w3-margin-right">location_on</i> Natal-RN, BR<br>
      <i class="material-icons w3-hover-text-black w3-xlarge w3-margin-right">phone</i> Telefone: +55 (84) 3232-3232<br>
      <i class="material-icons w3-hover-text-black w3-xlarge w3-margin-right">email</i> Email: carro@hicar.com<br>
  </div>
  </div>
</div>
</div>

        
	  <!-- Footer -->
	  <footer class="w3-container w3-center w3-dark-grey">
	    <a href="https://www.facebook.com/" style="text-decoration: none" target="_blank" class="fa fa-facebook-square w3-text-color-white w3-xxlarge w3-padding"></a>
      <a href="https://www.instagram.com/" style="text-decoration: none" target="_blank" class="fa fa-instagram w3-text-color-white w3-margin-top w3-xxlarge"></a>
      <a href="https://www.linkedin.com/" style="text-decoration: none" target="_blank" class="fa fa-linkedin w3-text-color-white w3-xxlarge w3-padding"></a>

	    <a href="#home"><i class="fa fa-chevron-circle-up w3-right w3-xxlarge" style="margin-top:4%; margin-right:2%;" alt="Início"></i></a>
	      <p class="w3-center w3-align">© 2018 Hi-Car All Rights Reserved</p><br/>
	  </footer>
	</body>
</html> 
