<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    
    require '../banco.php';
    
    if(!empty($_POST)) {
        //Acompanha os erros de validação
        $razaoErro     = null;
        $enderecoErro  = null;
        $montadoraErro = null;
        $cnpjErro      = null;
        
        $razao     = $_POST['razao'];
        $endereco  = $_POST['endereco'];
        $montadora = $_POST['montadora'];
        $cnpj      = $_POST['cnpj'];
        
        //Validaçao dos campos:
        $validacao = true;
        if(empty($razao)) {
            $razaoErro = 'Por favor digite a razão social!';
            $validacao = false;
        }

        if(empty($endereco)) {
            $enderecoErro = 'Por favor digite o endereço!';
            $validacao = false;
        }
        
        if(empty($montadora)) {
            $montadoraErro = 'Por favor digite a montadora!';
            $validacao = false;
        }

        if(empty($cnpj)) {
            $cnpjErro = 'Por favor digite o CNPJ!';
            $validacao = false;
        }

        //Inserindo no Banco:
        if($validacao) {
	        $pdo = Banco::conectar();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO empresa (razaoSocial, endereco, montadora, cnpj) VALUES(?,?,?,?)";
            $q = $pdo->prepare($sql);
            $q->execute(array($razao, $endereco, $montador, $cnpj));
	        Banco::desconectar();
            header("Location: index.php");
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	    <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    
    <body style="padding-top:100px">
        <div class="container">
            <div clas="span10 offset1">
                <div class="row">
                    <h3 class="well"> Adicionar Empresa </h3>
                    <form class="form-horizontal" action="create.php" method="post">
                        <div class="control-group <?php echo !empty($razaoErro)?'error ' : '';?>">
                            <label class="control-label">Razão Social</label>
                            <div class="controls">
                                <input size= "50" name="razao" type="text" placeholder="Razao social" required value="<?php echo !empty($razao)?$razao: '';?>">
                                <?php if(!empty($razaoErro)): ?>
                                    <span class="help-inline"><?php echo $razaoErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="control-group <?php echo !empty($enderecoErro)?'error ' : '';?>">
                            <label class="control-label">Endereço</label>
                            <div class="controls">
                                <input size= "50" name="endereco" type="text" placeholder="Endereco" required value="<?php echo !empty($endereco)?$endereco: '';?>">
                                <?php if(!empty($enderecoErro)): ?>
                                    <span class="help-inline"><?php echo $enderecoErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="control-group <?php echo !empty($montadoraErro)?'error ' : '';?>">
                            <label class="control-label">Montadora</label>
                            <div class="controls">
                                <input size= "50" name="montadora" type="text" placeholder="Montadora" required value="<?php echo !empty($montadora)?$montadora: '';?>">
                                <?php if(!empty($montadoraErro)): ?>
                                    <span class="help-inline"><?php echo $montadoraErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="control-group <?php echo !empty($cnpjErro)?'error ' : '';?>">
                            <label class="control-label">CNPJ</label>
                            <div class="controls">
                                <input size= "15" name="cnpj" type="text" placeholder="CNPJ" required value="<?php echo !empty($cnpj)?$cnpj: '';?>">
                                <?php if(!empty($cnpjErro)): ?>
                                    <span class="help-inline"><?php echo $cnpjErro;?></span>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="form-actions">
                            <br/>
                            <button type="submit" class="btn btn-success">Adicionar</button>
                            <a href="index.php" type="btn" class="btn btn-default">Voltar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>
