<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';

    $idEmpresa = null;
    if(!empty($_GET['id'])) {
        $idEmpresa = $_REQUEST['id'];
    }
    
    if(null==$idEmpresa) {
        header("Location: index.php");
    } else {
       $pdo = Banco::conectar();
       $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = "SELECT * FROM empresa where idEmpresa = ?";
       $q = $pdo->prepare($sql);
       $q->execute(array($idEmpresa));
       $data = $q->fetch(PDO::FETCH_ASSOC);
       Banco::desconectar();
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../js/bootstrap.min.js"></script>
	<script src="../js/jquery.min.js"></script>
    </head>
    <body style="padding-top:100px">
        <div class="container">           
            <div class="span10 offset1">
                <div class="row">
                    <h3 class="well">Detalhes da Empresa</h3>
                </div>
                
                <div class="form-horizontal">                   
                    <div class="control-group">
                        <label class="control-label">Razão Social</label>
                        <div class="controls">
                            <label class="carousel-inner">
                                <?php echo $data['razaoSocial'];?>
                            </label>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Endereço</label>
                        <div class="controls">
                            <label class="carousel-inner">
                                <?php echo $data['endereco'];?>
                            </label>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Montadora</label>
                        <div class="controls">
                            <label class="carousel-inner">
                                <?php echo $data['montadora'];?>
                            </label>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">CNPJ</label>
                        <div class="controls">
                            <label class="carousel-inner">
                                <?php echo $data['cnpj'];?>
                            </label>
                        </div>
                    </div>                                  
                    <br/>
                    <div class="form-actions">
                        <a href="index.php" type="btn" class="btn btn-default">Voltar</a>
                    </div>
                    
                </div>
            </div>
        </div>
    </body>
</html>

