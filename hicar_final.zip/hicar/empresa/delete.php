<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';

    $idEmpresa = null;
    if(!empty($_GET['id'])) {
        $idEmpresa = $_REQUEST['id'];
    }
    
    if(null==$idEmpresa) {
        header("Location: index.php");
    } else {
       $pdo = Banco::conectar();
       $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = "SELECT * FROM empresa where idEmpresa = ?";
       $q = $pdo->prepare($sql);
       $q->execute(array($idEmpresa));
       $data = $q->fetch(PDO::FETCH_ASSOC);
       Banco::desconectar();
    }

    if(!empty($_POST)) {
        $idEmpresa = $_POST['idEmpresa'];
        //Delete do banco:
        $pdo = Banco::conectar();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM empresa where idEmpresa = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($idEmpresa));
        Banco::desconectar();
        header("Location: index.php");
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top:100px">
        <div class="container">
            <div class="span10 offset1">
                <div class="row">
                    <h3 class="well">Excluir Empresa</h3>
                </div>
                <form class="form-horizontal" action="delete.php?id=<?php echo $idEmpresa?>" method="POST">
                    <input type="hidden" name="idEmpresa" value="<?php echo $idEmpresa;?>"/>
                    <div class="alert alert-danger"> Deseja excluir a empresa?
                    </div>
                    <div class="form actions">
                        <button type="submit" class="btn btn-danger">Sim</button>
                        <a href="index.php" type="btn" class="btn btn-default">Não</a>
                    </div>
                </form>
            </div>           
        </div>
    </body>    
</html>

