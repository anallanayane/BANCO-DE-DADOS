<?php
	session_start();
	$_SESSION['usuario'] = null;
	$_SESSION['funcionario'] = null;
	unset($_SESSION['usuario']);
	unset($_SESSION['funcionario']);
	header("Location: index.php");
?>
