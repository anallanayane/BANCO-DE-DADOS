<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    
    <body style="padding-top:100px">
        <div class="jumbotron">
        <div class="container">
            <div class="row">
                <h1>Ordens de Serviço</h1>
            </div>
            </br>
            <div class="row">
                <p>
                    <a href="create.php" class="btn btn-success">Adicionar</a>
                </p>
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Veículo</th>
                            <th>Funcionário</th>
                            <th>Data</th>
                            <th>Hora</th>
                            <th>Status</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $pdo = Banco::conectar();
                        $sql = 'SELECT os.idOs, os.data, os.hora, os.status, v.placa, p.nome as funcionario
                                FROM os, veiculo v, funcionario f, pessoa p
                                WHERE os.idVeiculo = v.idVeiculo AND
                                    os.idFuncionario = f.idFuncionario AND f.idPessoa = p.idPessoa
                                ORDER BY os.data desc, os.hora desc';
                        
                        foreach($pdo->query($sql)as $row) {
                            echo '<tr>';
                            echo '<td>'. $row['placa'] . '</td>';
                            echo '<td>'. $row['funcionario'] . '</td>';
                            echo '<td>'. date('d/m/Y', strtotime($row['data'])) . '</td>';
                            echo '<td>'. $row['hora'] . '</td>';
                            echo '<td>'. $row['status'] . '</td>';
                            echo '<td width=180>';
                            echo '<a class="btn btn-primary" href="read.php?id='.$row['idOs'].'">Listar</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="delete.php?id='.$row['idOs'].'">Excluir</a>';
                            echo '</td>';
                            echo '<tr>';
                        }
                        Banco::desconectar();
                        ?>
                    </tbody>                   
                </table>               
            </div>
        </div>
        </div>
    </body>
</html>
