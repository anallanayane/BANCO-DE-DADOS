<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';

    $idOs = null;
    if(!empty($_GET['id'])) {
        $idOs = $_REQUEST['id'];
    }
    
    if(null==$idOs) {
        header("Location: index.php");
    } else {
       $pdo = Banco::conectar();
       $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = 'SELECT os.idOs, os.data, os.hora, os.status, 
                      v.placa, v.modelo, v.cor, 
                      p.nome as funcionario, p.cpf, f.funcao
               FROM os, veiculo v, funcionario f, pessoa p
               WHERE os.idOs = ? AND os.idVeiculo = v.idVeiculo AND
                      os.idFuncionario = f.idFuncionario AND f.idPessoa = p.idPessoa
               ORDER BY os.data desc, os.hora desc';
       $q = $pdo->prepare($sql);
       $q->execute(array($idOs));
       $data = $q->fetch(PDO::FETCH_ASSOC);
       Banco::desconectar();
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <script src="../js/jquery.min.js"></script>
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top:100px">
        <div class="container">           
            <div class="span10 offset1">
                <div class="row">
                    <h3 class="well">Detalhes da OS</h3>
                </div>
                
                <div class="form-horizontal">                   
                    <div class="control-group">
                        <label class="control-label">Veículo</label>
                        <label class="carousel-inner">
                            <?php echo 'Placa: ' . $data['placa'] . '<br>Modelo: ' . $data['modelo'] . '<br>Cor: ' . $data['cor'];?>
                        </label>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Funcionário</label>
                        <label class="carousel-inner">
                            <?php echo 'Nome: ' . $data['funcionario'] . '<br>CPF: ' . $data['cpf'] . '<br>Função: ' . $data['funcao'];?>
                        </label>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Data - Hora</label>
                        <label class="carousel-inner">
                            <?php echo date('d/m/Y', strtotime($data['data'])) . ' - ' . $data['hora'];?>
                        </label>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Status</label>
                        <label class="carousel-inner">
                            <?php echo $data['status'];?>
                        </label>
                    </div>                        
                    <br/>

                    <p>
                        <a href="additem.php?id=<?php echo $idOs?>" class="btn btn-success">Adicionar</a>
                    </p>
                    <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Quantidade</th>
                            <th>Valor</th>
                            <th>Funcionário</th>
                            <th>Status</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $pdo = Banco::conectar();
                        $sql = 'SELECT o.idOsItens, o.idPeca, o.idServico, o.quantidade, o.valor, o.status, 
                                       p.nome as funcionario, pe.nome as peca, s.nome as servico
                                FROM (ositens o, funcionario f, pessoa p) LEFT JOIN 
                                      peca pe ON o.idPeca = pe.idPeca LEFT JOIN
                                      servico s ON o.idServico = s.idServico
                                WHERE o.idOs = ' . $idOs . ' AND o.idFuncionario = f.idFuncionario AND
                                    f.idPessoa = p.idPessoa
                                ORDER BY o.idOsItens';
                        
                        foreach($pdo->query($sql)as $row) {
                            echo '<tr>';
                            if($row['idPeca']==null)
                                echo '<td>'. $row['servico'] . '</td>';
                            else
                                echo '<td>'. $row['peca'] . '</td>';
                            echo '<td>'. $row['quantidade'] . '</td>';
                            echo '<td>'. $row['valor'] . '</td>';
                            echo '<td>'. $row['funcionario'] . '</td>';
                            echo '<td>'. $row['status'] . '</td>';
                            echo '<td width=150>';
                            echo '<a class="btn btn-danger" href="deleteitem.php?id='.$row['idOsItens'] . '&idOs=' . $idOs . '">Excluir</a>';
                            echo '</td>';
                            echo '<tr>';
                        }
                        Banco::desconectar();
                        ?>
                    </tbody>                   
                </table>  

                    <div class="form-actions">
                        <a href="index.php" type="btn" class="btn btn-default">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

