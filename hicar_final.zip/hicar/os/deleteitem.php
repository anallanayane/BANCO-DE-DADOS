<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];
    require '../banco.php';

    $idOsItens = null;
    if(!empty($_GET['id'])) {
        $idOsItens = $_REQUEST['id'];
        $idOs = $_REQUEST['idOs'];
    }
    
    if(null==$idOsItens) {
        header("Location: index.php");
    } else {
       $pdo = Banco::conectar();
       $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       $sql = "SELECT * FROM ositens where idOsItens = ?";
       $q = $pdo->prepare($sql);
       $q->execute(array($idOsItens));
       $data = $q->fetch(PDO::FETCH_ASSOC);
       Banco::desconectar();
    }

    if(!empty($_POST)) {
        $idEmpresa = $_POST['idOsItens'];
        //Delete do banco:
        $pdo = Banco::conectar();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM ositens where idOsItens = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($idOsItens));
        Banco::desconectar();
        header("Location: read.php?id=" . $idOs);
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    <body style="padding-top:100px">
        <div class="container">
            <div class="span10 offset1">
                <div class="row">
                    <h3 class="well">Excluir Item da OS</h3>
                </div>
                <form class="form-horizontal" action="deleteitem.php?id=<?php echo $idOsItens . '&idOs=' . $idOs; ?>" method="POST">
                    <input type="hidden" name="idOsItens" value="<?php echo $idOs;?>"/>
                    <div class="alert alert-danger"> Deseja excluir o item da os?
                    </div>
                    <div class="form actions">
                        <button type="submit" class="btn btn-danger">Sim</button>
                        <a href="read.php?id=<?php echo $idOs ?>" type="btn" class="btn btn-default">Não</a>
                    </div>
                </form>
            </div>           
        </div>
    </body>    
</html>

