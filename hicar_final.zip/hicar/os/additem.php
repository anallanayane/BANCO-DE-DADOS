<?php
    session_start();
    if(!isset($_SESSION['usuario'])) {
	    header("Location: ../index.php");
    }
    if(!isset($_SESSION['funcionario'])) {
        header("Location: ../pessoa/meusveiculos.php");
    }
    $id = $_SESSION['usuario'];
    $funcionario = $_SESSION['funcionario'];

    $idOs = null;
    if(!empty($_GET['id'])) {
        $idOs = $_REQUEST['id'];
    }
    
    if(null==$idOs) {
        header("Location: index.php");
    }
    
    require '../banco.php';
    
    if(!empty($_POST)) {
        //Acompanha os erros de validação
        $funcionarioServicoErro = null;
        $tipoServicoErro        = null;
        $quantidadeErro  = null;
        
        $funcionarioServico = null;
        $tipoServico        = null;
        $quantidade         = null;
        
        //Validaçao dos campos:
        $funcionarioServico = $_POST['funcionarioServico'];
        $tipoServico        = $_POST['tipoServico'];
        $quantidade         = $_POST['quantidade'];
        
        //Validaçao dos campos:
        $validacao = true;
        if(empty($funcionarioServico)) {
            $funcionarioServicoErro = 'Por favor selecione um funcionário!';
            $validacao = false;
        }

        if(empty($tipoServico)) {
            $tipoServicoErro = 'Por favor escolha um serviço!';
            $validacao = false;
        }

        if(empty($quantidade)) {
            $quantidadeErro = 'Por favor digite a quantidade!';
            $validacao = false;
        }
            
        //Inserindo no Banco:
        if($validacao) {
	        $pdo = Banco::conectar();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "INSERT INTO ositens (idOs, quantidade, valor, idPeca, idServico, idFuncionario, status) VALUES(?,?,?,?,?,?,?)";
            $q = $pdo->prepare($sql);
            if(substr($tipoServico, 0, 1) == 'P')
            $q->execute(array($idOs, $quantidade, 0, substr($tipoServico, 1), null, $funcionarioServico, 'A'));
            if(substr($tipoServico, 0, 1) == 'S')
            $q->execute(array($idOs, $quantidade, 0, null, substr($tipoServico, 1), $funcionarioServico, 'A'));
	        Banco::desconectar();
            header("Location: read.php?id=" . $idOs);
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php include '../cabecalho_cadastros.php'; ?>
        <meta charset="utf-8">
        <link href="../css/bootstrap.min.css" rel="stylesheet">
	    <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </head>
    
    <body style="padding-top:100px">
        <div class="container">
            <div clas="span10 offset1">
                <div class="row">
                    <h3 class="well"> Adicionar Item na OS </h3>
                    <form class="w3-container w3-card-4" action="additem.php?id=<?php echo $idOs?>" method="POST">
                        <h2 class="w3-center">Ordens de Serviço</h2> <br>
                        <div class="w3-section">
                            <select class="w3-select" name="funcionarioServico">
                            <option value="" disabled selected>Selecione um Funcionario</option>
                            <?php 
                                $pdo = Banco::conectar();
                                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                //LISTAR OS FUNCIONARIOS DA MESMA EMPRESA QUE O QUE ESTA LOGADO
                                $sql = "SELECT f.idFuncionario, p.nome, f.funcao FROM funcionario f, pessoa p WHERE f.idPessoa = p.idPessoa AND 
                                f.idEmpresa = (SELECT f1.idEmpresa FROM pessoa p1 INNER JOIN funcionario f1 ON p1.idPessoa = f1.idPessoa WHERE p1.idPessoa = $funcionario) ORDER BY p.nome";
                                $q = $pdo->prepare($sql);
                                $q->execute();
                                while($data = $q->fetch(PDO::FETCH_ASSOC)) {
                                echo '<option value="' . $data['idFuncionario'] . '"';
                                if($funcionarioServico == $data['idFuncionario'])
                                    echo ' selected';
                                echo '>' . $data['nome'] . ' (' . $data['funcao'] . ')</option>';
                                }
                                Banco::desconectar();
                            ?>
                            </select>
                            <?php if(!empty($funcionarioServicoErro)): ?>
                            <span class="help-inline"><?php echo $funcionarioServicoErro;?></span>
                            <?php endif;?>
                        </div>

                        <div class="w3-section">
                            <select class="w3-select" name="tipoServico">
                            <option value="" disabled selected>Selecione o tipo de serviço</option>
                            <?php 
                                $pdo = Banco::conectar();
                                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                //LISTAR TODAS AS PECAS E SERVICOS
                                $sql = "SELECT idServico as id, 'S' as tipo, nome, tempoMedio FROM servico
                                        UNION ALL
                                        SELECT idPeca as id, 'P' as tipo, nome, 0 as tempoMedio FROM peca
                                        ORDER BY 2, 3";
                                $q = $pdo->prepare($sql);
                                $q->execute();
                                $tipo = '';
                                while($data = $q->fetch(PDO::FETCH_ASSOC)) {
                                if($data['tipo'] != $tipo) {
                                    $tipo = $data['tipo'];
                                    if($data['tipo'] == 'P')
                                    echo '<option disabled value="">--- Peças ---</option>';
                                    if($data['tipo'] == 'S')
                                    echo '<option disabled value="">--- Serviços ---</option>';
                                }
                                    echo '<option value="' . $data['tipo'] . $data['id'] . '"';
                                    if($data['tipo'] . $data['id'] == $tipoServico)
                                    echo ' selected';
                                    echo '>' . $data['nome'] . ' (' . $data['tempoMedio'] . ' minutos)</option>';
                                }
                                Banco::desconectar();
                            ?>
                            </select>
                            <?php if(!empty($tipoServicoErro)): ?>
                            <span class="help-inline"><?php echo $tipoServicoErro;?></span>
                            <?php endif;?>
                        </div>
                        <div class="control-group <?php echo !empty($quantidadeErro)?'error ': '';?>">
                            <div class="controls">
                                <p><input class="w3-input" type="number" required placeholder="Quantidade" name="quantidade" maxlength="2" value="<?php echo !empty($quantidade)?$quantidade: '';?>"></p>
                                <?php if(!empty($quantidadeErro)): ?>
                                    <span class="help-inline"><?php echo $quantidadeErro;?></span>
                                <?php endif;?>
                            </div>
                        </div><br/><br/>
                        <div class="w3-section w3-right">
                            <button class="w3-right w3-button w3-margin-bottom w3-blue w3-hover-light-blue w3-round-large" type="submit">Confirmar Serviço</button>
                            <a href="read.php?id=<?php echo $idOs?>" type="button" class="w3-right w3-button w3-text-red w3-hover-red w3-round-large w3-margin-right">Cancelar</a><br>
                        </div>  
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>
